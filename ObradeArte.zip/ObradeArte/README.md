# 🎨 Galería de Arte  

**Prototipo N°1 - Desarrollo de Aplicaciones Empresariales**  

Este proyecto es un prototipo de aplicación para la gestión de una **Galería de Arte**, desarrollado como parte del curso de **Desarrollo de Aplicaciones Empresariales**.  

---

## 👥 Desarrollado por

- **Santiago Arciniegas** - 2220221016  
- **Daniel Mauricio Álvarez Morales** - 2420211008  
- **Brayan Santiago Cartagena Díaz** - 2220221056  
- **Julián Camilo Aranguren Herrán** - 2220231103  

---

## 📌 Descripción breve
La aplicación permite realizar operaciones CRUD sobre las obras de arte (agregar, listar, actualizar y eliminar), aplicando **Java Swing** bajo el patrón **MVC** y principios **SOLID**.  

---

## 🚀 Tecnologías utilizadas


---

## 📂 Estructura del proyecto
