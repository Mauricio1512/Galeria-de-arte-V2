/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.galeriaarte;

import com.mycompany.galeriaarte.view.GUIPrincipal;

/**
 *
 * @author SANTIAGO
 */
public class GaleriaArte {

    public static void main(String[] args) {
        GUIPrincipal gui = new GUIPrincipal();
        gui.setVisible(true);
    }
}
